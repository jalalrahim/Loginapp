package com.example.loginapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_create_notes.*

class CreateNotes : AppCompatActivity() {

        companion object {
            const val NOTE_EXTRA = "note_extra"
        }

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_create_notes)

            btn_save.setOnClickListener {
                val note = et_note.text.toString()
                if (note.isNotEmpty()) {
                    // save the note here
                    val intent = Intent(this,Notes::class.java)
                    intent.putExtra(CreateNotes.NOTE_EXTRA, note)
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "Please enter a note!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

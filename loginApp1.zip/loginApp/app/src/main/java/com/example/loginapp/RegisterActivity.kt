package com.example.loginapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_register.*

class RegisterActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        auth = FirebaseAuth.getInstance()

        SUBMIT.setOnClickListener() {
            if (checking()) {

                var email = EmailRegister.text.toString()
                var password = PasswordRegister.text.toString()
                var name=Name.text.toString()
                var reg=Registration.text.toString()
                auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this) {
                            task ->
                        if (task.isSuccessful)
                        {
                            Toast.makeText(this, "User Created", Toast.LENGTH_SHORT).show()

                        } else {
                            Toast.makeText(this, "Somthing went wrong", Toast.LENGTH_SHORT).show()
                        }


                    }


            } else {
                Toast.makeText(this, "Enter Credentials", Toast.LENGTH_SHORT).show()
            }

        }


    }

    private fun checking(): Boolean {
        if (EmailRegister.text.toString().trim { it <= ' ' }.isNotEmpty()
            && PasswordRegister.text.toString().trim { it <= ' ' }.isNotEmpty()
            && Name.text.toString().trim { it <= ' ' }.isNotEmpty()
            && Registration.text.toString().trim { it <=' ' }.isNotEmpty())
        {
            return true
        }
        return false
    }

}












package com.example.loginapp

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_notes.*

class Notes : AppCompatActivity() {
    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notes)


        val note = intent.getStringExtra(CreateNotes.NOTE_EXTRA)
        findViewById<TextView>(R.id.tv_note).text = note


            create_notes.setOnClickListener(){
            var intent= Intent (this,CreateNotes::class.java)
            startActivity(intent)
        }

        edit_notes.setOnClickListener(){
            var intent= Intent (this,CreateNotes::class.java)
            startActivity(intent)
        }


    }
}